package bean;

public class CustomerBean
{
    private int customer_id; //PK
    private String username;
    private String password;
    private int cid; // FK to CustomerInfo
    private String registration_date;

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public int getCid() {
        return cid;
    }
    public void setCid(int cid) {
        this.cid = cid;
    }
}
