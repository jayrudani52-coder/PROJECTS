package dao;

import bean.PaymentsBean;
import util.dbConnection;

import java.sql.*;
import java.util.Scanner;

public class PaymentsDao
{
    static Connection con;
    static {
        try {
            con = dbConnection.getConnection();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static void main(String[] args) throws Exception
    {
        Statement st = con.createStatement();
        String createPayments ="CREATE TABLE IF NOT EXISTS Payments (" +
                "  payid INT PRIMARY KEY AUTO_INCREMENT," +
                "  cid INT NOT NULL," +
                "  amount DECIMAL(10,2) NOT NULL," +
                "  paymentdate DATE DEFAULT CURRENT_DATE," +
                "  payment_mode VARCHAR(20)," +
                "  CONSTRAINT fk_payments_cid " +
                "    FOREIGN KEY (cid) REFERENCES CustomerInfo(cid) " +
                "    ON UPDATE CASCADE ON DELETE CASCADE)";
        st.executeUpdate(createPayments);
    }
    public static void insert(PaymentsBean p) throws Exception
    {
        String insertPayments = "INSERT INTO Payments(cid,amount,payment_mode) VALUES(?,?,?)";
        PreparedStatement ps = con.prepareStatement(insertPayments);
        ps.setInt(1, p.getCid());
        ps.setDouble(2, p.getAmount());
        ps.setString(3, p.getPayment_mode());
        ps.executeUpdate();
    }

    /*public  static void delete(PaymentsBean p) throws Exception
    {
        String deletePayments = "DELETE FROM Payments WHERE cid=?";
        PreparedStatement ps = con.prepareStatement(deletePayments);
        ps.setInt(1, p.getCid());
    }*/
}
