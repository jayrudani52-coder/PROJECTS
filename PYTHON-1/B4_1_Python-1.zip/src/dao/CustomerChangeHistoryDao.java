package dao;

import bean.CustomerChangeHistoryBean;
import util.dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;

public class CustomerChangeHistoryDao
{
    static Connection con;
    static {
        try {
            con = dbConnection.getConnection();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static void main(String[] args) throws Exception
    {
        Statement st = con.createStatement();
        String createCustomerChangeHistory = "CREATE TABLE IF NOT EXISTS CustomerChangeHistory (" +
                "  history_id INT PRIMARY KEY AUTO_INCREMENT," +
                "  cid INT NOT NULL," +
                "  field_changed VARCHAR(20) NOT NULL," +   // bmi/height/weight (validate in Java)
                "  old_value VARCHAR(50)," +
                "  new_value VARCHAR(50)," +
                "  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                "  CONSTRAINT fk_custchange_cid " +
                "    FOREIGN KEY (cid) REFERENCES CustomerInfo(cid) " +
                "    ON UPDATE CASCADE ON DELETE CASCADE)";
        st.executeUpdate(createCustomerChangeHistory);

    }
    /*public static void insert(CustomerChangeHistoryBean c) throws Exception
    {
        String insert = "Insert into CustomerChangeHistory(cid,field_changed,old_value, new_value)"+
                        "VALUES(?,?,?,?)";
        PreparedStatement ps = con.prepareStatement(insert);
        ps.setInt(1,c.getCid());
        ps.setString(2,c.getField_changed());
        ps.setString(3,c.getOld_value());
        ps.setString(4,c.getNew_value());
        ps.executeUpdate();
    }*/

    public  static void delete(CustomerChangeHistoryBean c) throws Exception
    {
        String delete = "delete from CustomerChangeHistory where cid = ?";
        PreparedStatement ps = con.prepareStatement(delete);
        ps.setInt(1,c.getCid());
    }
}
