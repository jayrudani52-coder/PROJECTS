package dao;

import bean.MedicalHistoryBean;
import util.dbConnection;

import java.sql.*;
import java.util.Scanner;

public class MedicalHistoryDao
{
    static Connection con;
    static {
        try {
            con = dbConnection.getConnection();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static void main(String[] args) throws Exception
    {
        Statement st = con.createStatement();
        String createMedicalHistory = "CREATE TABLE IF NOT EXISTS MedicalHistory (" +
                "  mid INT PRIMARY KEY AUTO_INCREMENT," +
                "  cid INT NOT NULL," +
                "  disease_name VARCHAR(100) NOT NULL," +
                "  nature VARCHAR(100)," +
                "  duration VARCHAR(50)," +
                "  medications VARCHAR(255)," +
                "  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP " +
                "  ON UPDATE CURRENT_TIMESTAMP," +
                "  CONSTRAINT fk_medhist_cid " +
                "  FOREIGN KEY (cid) REFERENCES CustomerInfo(cid) " +
                "  ON UPDATE CASCADE ON DELETE CASCADE)";
        st.executeUpdate(createMedicalHistory);
    }
    public static void insert(MedicalHistoryBean m) throws Exception
    {
        String insertMedicalHistory = "INSERT INTO MedicalHistory(cid, disease_name,nature,duration,medications)" +
                                      " VALUES(?,?,?,?,?)";
        PreparedStatement ps = con.prepareStatement(insertMedicalHistory);
        ps.setInt(1, m.getCid());
        ps.setString(2,m.getDisease_name());
        ps.setString(3,m.getNature());
        ps.setString(4,m.getDuration());
        ps.setString(5,m.getMedications());
        ps.executeUpdate();
    }
    public  static void update(MedicalHistoryBean m) throws Exception
    {
        String updateMH = "UPDATE MedicalHistory SET disease_name = ? WHERE cid = ?";
        PreparedStatement ps = con.prepareStatement(updateMH);
        ps.setString(1,m.getDisease_name());
        ps.setInt(2,m.getCid());
    }
    public  static void delete(MedicalHistoryBean m) throws Exception
    {
        String deleteMedicalHistory = "DELETE FROM MedicalHistory WHERE cid = ?";
        PreparedStatement ps = con.prepareStatement(deleteMedicalHistory);
        ps.setInt(1, m.getCid());
    }

    public static String diseaseName(MedicalHistoryBean m) throws Exception
    {
        String select = "Select disease_name from MedicalHistory where cid = ?";
        PreparedStatement ps = con.prepareStatement(select);
        ps.setInt(1, m.getCid());
        ResultSet rs = ps.executeQuery();
        String disease_name = "";
        while(rs.next())
        {
            disease_name = disease_name +" "+ rs.getString(1);
        }
        return disease_name;
    }
}
