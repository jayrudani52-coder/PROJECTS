package dao;

import bean.CustomerMeasurementBean;
import util.dbConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class CustomerMeasurementDao
{
    static Connection con;
    static {
        try {
            con = dbConnection.getConnection();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static void main(String[] args) throws Exception
    {
        Statement st = con.createStatement();
        String createCustomerMeasurement = "CREATE TABLE IF NOT EXISTS CustomerMeasurement (" +
                "  measure_id INT PRIMARY KEY AUTO_INCREMENT," +
                "  cid INT NOT NULL," +
                "  height_cm NUMERIC," +
                "  weight NUMERIC," +
                "  bmi NUMERIC," +
                "  bmiCategory VARCHAR(20)," +
                "  recorded_date DATE DEFAULT CURRENT_DATE," +
                "  CONSTRAINT fk_measure_cid " +
                "  FOREIGN KEY (cid) REFERENCES CustomerInfo(cid) " +
                "  ON UPDATE CASCADE ON DELETE CASCADE)";
        st.executeUpdate(createCustomerMeasurement);
    }
    public static void insert(CustomerMeasurementBean c) throws Exception
    {
        String insert = "INSERT INTO CustomerMeasurement (cid, height_cm, weight, bmi, bmiCategory) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(insert);
        ps.setInt(1,c.getCustomerId());
        ps.setDouble(2, c.getHeight());
        ps.setDouble(3, c.getWeight());
        ps.setDouble(4, c.getBmi());
        ps.setString(5, c.getBmiCategory());
        ps.executeUpdate();
    }
    public  static void update(CustomerMeasurementBean c, int choice) throws Exception
    {
        if(choice == 2)
        {
            double bmi = (c.getWeight()*10000)/Math.pow(c.getHeight(),2);
            c.setBmi(bmi);
            String updateHeight = "UPDATE CUSTOMERMEASUREMENT SET height_cm = ?, weight = ?, bmi = ? WHERE cid = ?";
            PreparedStatement ps1 = con.prepareStatement(updateHeight);
            ps1.setDouble(1, c.getHeight());
            ps1.setDouble(2, c.getWeight());
            ps1.setDouble(3, c.getBmi());
            ps1.setInt(4, c.getCustomerId());
            ps1.executeUpdate();
        }
        else if(choice == 3)
        {
            String updateHeight = "UPDATE CUSTOMERMEASUREMENT SET weight = ? WHERE cid = ?";
            PreparedStatement ps = con.prepareStatement(updateHeight);
            ps.setDouble(1, c.getWeight());
            ps.setInt(2, c.getCustomerId());
            ps.executeUpdate();
        }
    }
    public  static void delete(CustomerMeasurementBean c) throws Exception
    {
        String delete = "Delete from customer_measurement where cid = ?";
        PreparedStatement ps = con.prepareStatement(delete);
        ps.setInt(1,c.getCustomerId());
    }
}
