package util;

public class InvalidPhoneException extends Exception {
    public InvalidPhoneException(String msg) { super(msg); }
}
